import { defineConfig } from 'astro/config';

export default defineConfig({
  site: 'https://www.seusite.com.br',
  outDir: './dist'
});
